---
title: International
---

### International Activities
COMET and its associated education website MetEd are pivotal resources that support international training needs for geoscience professionals in many countries. Throughout its 25-year history, COMET has been instrumental in facilitating the exchange of ideas and building capacity within the worldwide hydrometeorological community. Approximately 30% of the 450,000 users currently registered on the MetEd website are from outside the United States, and collectively represent 190+ countries.

Through international partnerships with organizations such as the International Activities Office of the U.S. National Weather Service (NWS IAO), the World Meteorological Organization Education and Training Office (WMO ETO), EUMETSAT, the Meteorological Service of Canada, the Bureau of Meteorology in Australia (BoM) and others, COMET has increased the amount of resources that are of interest to the international community.

#### COMET’s Role in Supporting National Meteorological and Hydrological Services
COMET’s international work reflects the critical priorities of the NOAA’s National Weather Service. One of NOAA’s goals is to develop and update environmental observing and prediction capacity, particularly in developing nations. Ultimately the objective is to reduce loss of life, property, and disruption from high-impact weather or other catastrophic natural events, and support what NOAA calls “weather and climate-ready nations.”

#### Translations & Localizations of Geoscience Training
To better serve the international community, COMET has translated over 100 lessons into Spanish and created an entire Spanish version of its MetEd website. A number of lessons are also available in other languages including French, German, Chinese, Russian, Portuguese and Indonesian. COMET social media properties also engage participants from all over the world to form a global meteorological community. Operational meterologists in countries with limited training resources depend on COMET's materials on the MetEd website, to improve their basic forecasting skills, and to incorporate new technologies into their work.

Working with NWS IAO, EUMETSAT, and the Australian BoM, COMET has created a number of international adaptations. Selected examples include:

*     Numerical Weather Prediction Essentials
*     Introduction to Aircraft Meteorological Data Relay (AMDAR) Learn more
*     Climate Variability
*     Change for Water Resources Management

Learn about more about COMET's international work

### Support for the International Community
Improving forecast and warning capabilities and developing capacity of the international weather, water, and climate communities requires multifaceted efforts. Such efforts include advancing scientific understanding of natural and human-influenced processes; implementing impact-based forecast and decision support procedures, and upgrading observing, monitoring, and communications systems. Finally, training and education related to new technology, such as the GOES-R and JPSS satellite series, and numerical weather prediction models, will facilitate the use of these new data in forecasting operations.

#### COMET Supports National Meteorological Services Worldwide on Behalf of NWS
COMET has an important relationships with the International Activities Office of the U.S. National Weather Service (NWS IAO), whose mission is to improve forecasting through international cooperation, provide global leadership in setting meteorological standards and build partnerships to save lives and protect property. In particular COMET will be assisting NWS with capacity development in emerging countries, helping them disseminate information regarding weather, water and climate. Capacity development can include many things in this context including training in operational forecasting, and on newly deployed and enhanced observing and monitoring networks, and training on infrastructure maintenance and application of new observational data in operational settings.

#### COMET'S INTERNATIONAL SPONSORS
In addition to providing training materials for the US National Weather Service – which provide a critical service to international users – COMET develops customized training materials for the meteorological services of other countries including:

*     Meteorological Service of Canada -Winter weather, hydrology
*     Australian Bureau of Meteorology - Training the trainer
*     Korean Meteorological Administration - Winter weather, in preparation for the 2018 Winter Olympics in PyeongChang, Korea 
*     EUMETSAT – ASMET - Aviation forecasting for Africa

#### World Meteorological Organization (WMO)
COMET supports a WMO Global Campus initiative to expand learning opportunities to National Meteorological and Hydrological Services (NMHS).  COMET’s MetEd website with its 800 hours of training materials, is regarded as a foundational element of the WMO Global Campus.  

Recently, COMET’s efforts have evolved to align training to new competency frameworks specified under the World Meteorological Organization (WMO). The WMO objective for capacity development focuses on using partnerships to improve capabilities of National Meteorological and Hydrological Services (NMHSs), particularly in developing countries.  

#### COMET International Leadership: CALMet and SCHOTI
COMET has been active for many years on WMO task teams and expert panels, and is an active member of the Community for the Advancement of Learning in Meteorology (CALMet) as well as the WMO Standing Conference of the Heads of Training Institutions of National Meteorological 

Services (SCHOTI).  These organizations work to promote the sharing of experiences and strategies for applying emerging technologies in meteorology education and training.

#### International Resources for Capacity Development

*     Distance learning lessons for geoscience professionals available worldwide.
*     Translations of relevant lessons into Spanish, French, Chinese and other languages.
*     Virtual courses providing synchronous, instructor-led training to attendees at geographically diverse locations.
*     Classes hosted by the COMET program at UCAR headquarters in Boulder, Colorado.
*     Classes conducted by COMET staff on location at international sites

#### COMET & RANET

Technological and scientific advances in recent decades have produced a variety of meteorological products that can help humans manage systems sensitive to meteorological events, seasonal variability and climate change. Unfortunately, rural and technologically disadvantaged populations—often those most in need of this information—do not always have the access or training to take advantage of these products, many of which are freely available through national, regional and international organizations.

COMET will be supporting RANET, via its relationship with NOAA, to make climate and weather related information more accessible to rural populations and communities, through the use of innovative technologies, and expansion of existing networks and training.

The RANET program has conducted events in over 50 countries, and continues to expand capacity development efforts in Africa, Asia and the Southwest Pacific. With funding from NWS IAO, RANET and COMET have maintained multilingual training courses and a very active translation program for distance learning materials.
