---
title: 'Director''s Page'
content:
    items: '@self.children'
    limit: '5'
    order:
        by: date
        dir: desc
    pagination: '1'
---

Dr. Jeffries became Director of COMET in 2013. Under his leadership, the program has successfully fulfilled requirements and expectations of COMET’s current cooperative agreement with NOAA, and he is recognized as an outstanding geoscience professional. Through his role on the WMO Executive Committee Panel of Experts on Education and Training, he has led numerous working groups, workshops and learning events focused on continuous advances in the environmental sciences and climate change adaptation in the international community. In 2016, Dr. Jeffries helped coordinate the international working group focused on extending best practices for impact-based forecasts and warnings in developing countries, and was recently appointed as a Co-Chair of the WMO Global Campus working group.
{{ page.media['rich_jeffries.jpg'].html('', 'Dr. Richard Jeffries', 'pull-right') }}

### Operational Forecasting
Dr. Jeffries has served as an aviation weather forecaster, a maritime forecaster, and a typhoon forecaster. His experience allowed him to develop an appreciation for the training and education needs of the operational community. In addition, he engaged in operational meteorological research and development and was active in the design, management, and analysis of numerical modeling related to tropical cyclone forecasting. He served as director of operations at the Joint Typhoon Warning Center where he developed corporate officer management skills to work closely with a variety of business segments.

### Training and Education
Dr. Jeffries managed training and education requirements and implementation for 12 years within the Naval Meteorological and Oceanography Command (NMOC). He served as both the Executive Officer and Commanding Officer of the Naval Meteorology and Oceanography Professional Development Center. Additionally, he served as both the Deputy Assistant Chief of Staff for Human Resources and the Assistant Chief of Staff for Readiness, Training and Education for the Commander NMOC, where he focused on processes to convert resources and requirements into training and education services focused toward improving on-the-job performance. He is a recognized expert in capacity development including the components of integrating technology development, workforce development and succession planning, and economic development to implement new forecasting technology into existing workforces.

Dr. Jeffries holds an M.S. in meteorology from the Naval Postgraduate School, and a Ph.D.in Human Capital Development from the University of Southern Mississippi.