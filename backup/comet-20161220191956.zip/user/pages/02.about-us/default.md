---
title: 'About Us'
content:
    items: '@self.modular'
    order:
        by: date
        dir: desc
---

### About Us
COMET<sup>®</sup> has been providing training and education resources to the geosciences community for 25 years via cutting-edge classroom and distance learning technologies. COMET's MetEd website is the portal to a rich, online library of award-winning multilingual, interactive training resources. Over 800 hours of self-paced educational materials are available for working professionals, students and weather enthusiasts in a broad range of geoscience topics including meteorology, hydrology, climate science, geodesy and space weather - to mention only a few. 

The COMET Program was established in 1989 by UCAR and NOAA’s NWS to promote a better understanding of mesoscale meteorology among weather forecasters and to maximize the benefits of new weather technologies during the NWS’s modernization program. The COMET mission has expanded, and today COMET uses innovative methods to disseminate and enhance scientific knowledge in the environmental sciences, particularly meteorology, but also including diverse areas such as oceanography, hydrology, space weather and emergency management.

COMET has an outstanding, highly trained team of instructional designers, meteorologists, environmental scientists, graphic artists, multimedia developers, and information technology and administrative professionals. A COMET strength is the flexibility of its staff, which allows effective use of program funds and efficient production.
