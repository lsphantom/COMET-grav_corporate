---
title: 'NOAA - National Weather Service (NWS)'
published: true
body_classes: sponsor-page
---

![](pagecover-nws.jpeg)
### NOAA - National Weather Service (NWS)

{{ page.media['nws-logo.png'].html('NOAA - NWS', 'NOAA - NWS', 'thumb-wrap nws-logo') }}
COMET is a five-year Cooperative Partner with the U.S. National Oceanographic and Atmospheric Administration, and one of our most important clients within NOAA is the National Weather Service (NWS). COMET and the NWS have an enduring relationship that has lasted for over 25 years.

COMET training is designed to advance the skills of operational meteorologists, hydrologists, other environmental scientists, and the public. The training takes place across platforms that include distance learning, residence classroom instruction and virtual courses – all with a focus on decision support. Our approach aims to teach users to work in an integrated manner to improve joint decision-making and to build a weather and climate-ready nation.

#### Decade-Long Modernization Project at NWS
To improve its weather forecasting, NOAA's NWS embarked on a massive technological upgrade that began in 1989. The NWS built a new Dopplar radar network across the country, created a nationwide system of automated ground instruments, and radically increased its computing power.

#### COMET's Initial Role Led to Production of Distance Learning Resources
COMET was created to train thousands of meteorologists to integrate these new resources and the vast quantity of data they would produce, into the forecast process. Fortuitously, NWS requirements for widespread distribution of educational materials led COMET to develop early expertise in distance learning. That in turn led COMET to launch the MetEd website, which now hosts over 800 hours of self-paced learning materials for users all over the world. 

#### National Weather Service Programs within COMET
Recently, COMET has produced distance learning materials on a range of topics including aviation weather, climate, geospatial information, marine support, numerical weather prediction, satellite interpretation and winter weather. Although the National Weather Service continues to be a vital partner, COMET has major initiatives with other NOAA programs: NESDIS, NOAA's Satellite and Information Service, and NOAA's National Ocean Service.

**International Projects:**
Much of COMET's international work reflects the priorities of NOAA's National Weather Service. One of NOAA's goals is to promote environmental observing and prediction capacity, particularly in developing nations. Ultimately, the objective is to reduce loss of life, property, and disruption from high-impact weather or other catestrophic natural events, and support what NOAA calls "weather and climate-ready nations.

#### Training Highlights
*     **SKYWARN ® Spotter Training**.  Training and Certification for volunteer Weather Spotters. This hugely popular online series teaches would-be spotters how to predict and report severe weather events. Learn more.
*     **Numerical Weather Prediction**: Updates on computer modeling of weather systems, and the skills required to work with them, as ensemble weather forecasting evolves to replace deterministic forecasting. Learn more.
*    ** Aviation Forecasting** – Training in fog, ice, tropical storms and other topics from the perspective the aviation forecaster. Learn more.
*     **Hazards** – Community resilience, extreme weather, decision support and, fire weather. Learn more.
*     **Weather-Ready Nation Ambassador program**. Learn more.
*     Use MetEd Search to find a wide range of geoscience training subjects. Visit MetEd
