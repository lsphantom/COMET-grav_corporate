---
title: 'NOAA - National Ocean Service'
---

![](pagecover-nos.jpeg)
### NOAA - National Ocean Service

{{ page.media['noaa_logo.png'].html('NOAA - NOS', 'NOAA - NOS', 'thumb-wrap noaa-logo') }}
The mission of NOAA’s National Ocean Service is to "provide science-based solutions through collaborative partnerships to address evolving economic, environmental, and social pressures on our oceans and coasts." A scientific and technical organization of 1,700 scientists, natural resource managers, and specialists in many different fields, NOS delivers a range of scientific, technical, and resource management services to promote safe, healthy, and productive Great Lakes, oceans and coastal areas. Currently 40% of the US population lives in coastal counties, and they contribute nearly half of the US Gross Domestic Product to the national economy. It is vital to protect these coastal areas for multiple reasons.

#### New Challenges Confront the National Ocean Service (NOS)
Important environmental changes and accelerating coastal development are putting increased pressure on our coastal areas and oceans. According to the National Ocean Service “…immediate and potentially life-threatening events such as hurricanes as well as long-term environmental impacts from climate change are very real challenges to sustaining healthy coastal communities and ecosystems…these risks are likely increasing with the potential for a higher frequency of major storm events combined with enhanced risks of greater coastal impacts due to sea-level rise and coastal erosion.” The most important risks facing the National Ocean Service are:

*     Climate change
*     Extreme weather including higher intensity coastal storms
*     Coastal inundation due to changing sea levels
*     Oil and chemical spills
*     Impacts of coastal development

#### Protecting Coastal and Ocean Environments 

The National Ocean Service is working in three priority areas in order to support resilient and healthy coastal communities, economies and ecosystems:

**1 - Coastal resilience: preparedness, response, and recovery**

In light of increasing threats to our coasts, the NOS reports that coastal resiliency has become a national priority. The agency is confronting events ranging from oil spills to hurricanes, marine debris and grounded vessels. The solution? Improved decision making and end-to-end coastal preparedness, response, recovery, and resiliency.

**2 - Coastal intelligence**

To help decision makers in coastal areas determine the best choices for their communities, the National Ocean Service provides tools and services to facilitate that. Nautical charts, survey data, environmental monitoring and assessment and socioeconomic tools all integrate science and services to provide actionable information for community leaders in coastal areas.

**3 - Place-based conservation. **

The National Ocean Service works to conserve what’s best about coastal places, because they provides important economic benefits to local communities through recreation and tourism dollars. Protection of diverse marine ecosystems has long-term economic benefits to the US as a whole. The Coastal Zone Management, Coastal and Estuarine Land Conservation Program, the National Estuarine Research Reserve System, National Marine Sanctuaries, and the Coral Reef Conservation Program – all contribute to the preservation of marine ecosystems along with their co-located communities.
COMET Work with the National Ocean Service

Whether directly sponsored by NOS, or in collaboration with other federal agencies sharing similar goals, the COMET Program has produced a wide variety of lessons on geoscience topics pertinent to coastal areas. They include preparation for hurricanes and severe weather events including storm surge and flash flooding; response to oil spills and other man-made hazards; oceanography and ocean acidification; and lessons on understanding the needs of marine customers. In addition, COMET has been developing new series of lessons and short videos on geodesy, mapping and geographic information systems.

#### Additional Topics: See METED

*     Geospatial Infrastructure and Sea Level Rise Adaptation
*     Introduction to Geodesy and Mapping  Learn more
*     Storm Surge and Datums  Learn more
*     Understanding Heights and Vertical Datums  Learn more
*     Precision and Accuracy in Geodetic Surveying  Learn more
