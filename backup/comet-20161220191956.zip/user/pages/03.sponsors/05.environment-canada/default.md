---
title: 'Environment Canada'
published: true
---

![](pagecover-msc.jpeg)

### Environment Canada
<!--div id="msc-logo" class="thumb-wrap"></div-->
{{ page.media['canada_flag.png'].html('Environment Canada: Meteorological Service of Canada', 'Environment Canada: Meteorological Service of Canada', 'thumb-wrap') }}
A division of Environment Canada, the Meteorological Service of Canada (MSC) provides weather forecasts, warnings of severe weather, environmental hazards, and other public meteorological information. MSC also monitors and conducts research on climate, atmospheric science, air quality, water, ice and other environmental issues. MSC operates Weatheradio Canada, the country’s Canada’s 24/7 weather radio network.

The MSC manages Canadian storm prediction through a national network of weather forecast offices as well as several centers dedicated to specialized forecasting (eg. aviation).  The MSC also provides lead responsibility for the Canadian Meteorological Centre and the Canadian Ice Service; the latter provides forecasts for mariners and ice observations.

#### Long-term partnership with COMET

COMET and MSC began working together in the mid-1990s, and MSC became an official sponsor in early 2000. One of COMET’s first goals was to assist with a large management training effort, similar to the 1990 mission with the U.S. National Weather Service that originally launched COMET.

Describing the Second Winter Weather Forecasting Course at COMET in 2002, MSC meteorologist Peter Lewis said “The aims of this partnership include moving towards establishing a more formalized approach to the professional training and development of operational forecasters in the MSC and creating closer links between the research and forecasting communities. “ This trend continues today.

COMET has produced numerous self-paced lessons with MSC support, and their staff members come to Boulder often for classroom-based training. In 2016, COMET hosted the 16th offering of the Winter Weather Forecasting training course, and in the past has offered a mountain meteorology course that prepared forecasters supporting the 2010 Olympics, in Vancouver and Whistler, BC. Lessons on a variety of topics are available via distance learning.
#### COMET Work with Meteorological Service of Canada

*     Numerical Weather Prediction
*     Forecast Uncertainty
*     Probabilistic Forecasting
*     Satellite Feature Identification
*     Winter Weather
