---
title: EUMETSAT
---

![](pagecover-eumetsat.jpeg)
### EUMETSAT
{{ page.media['eumetsat_logo.jpeg'].html('EUMETSAT', 'EUMETSAT', 'thumb-wrap eumetsat-logo') }}
COMET has collaborated on projects with EUMETSAT - Europe’s intergovernmental satellite agency - for decades. Similar to NOAA’s satellite programs, the goal of the EUMETSAT program is to provide weather, climate and other environmental satellite data to the National Meteorological Services of its 30 member countries and other partners. 

#### EUMETSAT Satellite System
EUMETSAT uses the geostationary Meteosat weather satellites, along with the low Earth orbiting MetOp and Jason satellite series to track weather developments and long-term changes in the Earth’s climate.

#### EUMETSAT Shares Polar Satellite Resources with NOAA
The MetOp and Suomi NPP, a precursor to JPSS polar-orbiting satellites, fly complimentary polar orbits so that Europe and the US can share data for more globally relevant observations. Working with the UN World Meteorological Organization, EUMETSAT is striving to increase its collaboration with satellite environmental monitoring programs in other countries.

#### ASMET: COMET Project with EUMETSAT

The African Satellite Meteorology Education and Training (ASMET) - a project of EUMETSAT - works to improve weather forecasting in Africa by teaching meteorologists to make full use of meteorological satellite products in their work. COMET is an original member of the ASMET team, along with EUMETSAT, and meteorological instructors from South Africa, Kenya, Niger and Morocco.

ASMET lessons are posted on the MetEd website where they are freely available to the public and published in English and French.

To view recent ASMET productions please visit MetEd. Topics include:

*     High Swell Events on Moroccan Coast
*     Marine Forecasting Using ASCAT Data
*     Flooding in West Africa  Learn more
*     Satellite Monitoring of Convection over West and Central Africa

ASMET materials also include case studies on aviation forecasting in Africa, managing drought and hydrology, satellite meteorology in Africa and other topics. To view the complete list, please visit ASMET.