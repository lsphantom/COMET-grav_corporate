---
title: 'U.S. Bureau of Reclamation'
---

![](pagecover-bor.jpeg)
### U.S. Bureau of Reclamation
{{ page.media['bor-logo.png'].html('U.S. Bureau of Reclamation', 'U.S. Bureau of Reclamation', 'thumb-wrap bor-logo') }}
The COMET Program began working with the U. S. Bureau of Reclamation in 2012 to provide training and education materials to hydrologists and other water professionals on a broad range of issues relating to water management and climate impacts on water resources. These training materials offer users the opportunity to develop scientific knowledge and sound approaches to planning for climate change.

The Bureau of Reclamation has worked primarily in the West ever since 1902 to promote economic development through the construction of dams, reservoirs, canals and hydroelectric power plants. The Bureau is the largest wholesale provider of water in the U.S.  But, the population is growing more rapidly in the West than in any other part of the country, increasing overall demand for limited water resources and pitting competing uses – such as agriculture and urban development – against each other. It is the Bureau’s mission to meet these demands, while protecting the environment and existing water infrastructure.  Furthermore, the Bureau has a mandate to develop training resources that will serve long-term management of water resources under climate change and drought conditions.

#### COMET Training in Hydrology and Water Management

COMET has partnered with the Bureau of Reclamation and other members of the federal Climate Change and Water Working Group (CCAWWG) including the U.S. Army Corps of Engineers, Environmental Protection Agency, Western Water Assessment, and Denver Water. The project goal has been to create multiple onsite courses and online training across a broad range of water management topics.  The audience for these courses includes hydrologists, urban water resource managers, environmental scientists, civil engineers, climate scientists and others. All of the lessons created so far generally explore the theme of assessing climate change impacts on natural resources.

#### Additional Topics: see MetEd

*     Hydrology and Climate Change
*     Impacts of Temperature on Stream Ecosystems
*     Sedimentation and River Hydraulics
*     Water Resources Planning and Climate Change 
