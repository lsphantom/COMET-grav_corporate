---
title: 'NOAA - NESDIS'
---

![](pagecover-nesdis.jpeg)
### NOAA - National Environmental Satellite, Data, and Information Service (NESDIS)
{{ page.media['noaa_logo.png'].html('NOAA', 'NOAA - NESDIS', 'thumb-wrap noaa-logo') }}
The mission of NOAA’s **National Environmental Satellite, Data and Information Service (NESDIS)** is to provide global environmental information from satellites and other sources contributing crucial economic, security and environmental benefits to the U.S. The NOAA NESDIS service acquires and manages the Nation’s environmental satellites as well as the NOAA National Data Centers. NOAA also provides Earth system monitoring to the research and operational community, and conducts its own research, including official environmental assessments.

The data and information services provided by NESDIS support management of energy, water, global food supplies and other resources, as well as monitoring of important changes in the Earth’s atmosphere, biosphere, and climate.


#### NOAA’s Integrated Observing System
NOAA maintains two constellations of satellites: polar orbiting and geostationary. These satellites - together with radars, automated weather stations on the Earth’s surface, weather balloons, buoys, research aircraft, other sensors, and a management infrastructure for all the data they generate – make up the integrated observing system.

#### Weather, Climate and Oceans
NOAA uses the information it gets from this integrated observing system to meet its key goals: a weather-ready nation, climate adaptation and mitigation, healthy oceans, and resilient coastal communities and ecosystems.  COMET works with NOAA to provide classroom and online training to meet each of these important goals.

#### COMET and NESDIS
COMET has had a long-standing relationship with NESDIS, producing educational materials on the capabilities and applications of polar-orbiting and geostationary satellites, and their relevance to operational meteorology. By partnering with its Cooperative Institutes, including the Meteorological Service of Canada, EUMETSAT and the Naval Research Laboratory among others, COMET training stimulates greater use of current and future satellite observations and products. COMET has produced over 70 satellite-focused, self-paced lessons that are freely available in English, and a smaller number translated into Spanish and French.  In order to review lessons this topic please visit the COMET online learning platform, MetEd.

#### GOES-R & JPSS
COMET’s newest satellite training materials are focused on the latest constellations of environmental satellites including the geostationary GOES-R+ series, and the polar-orbiting S-NPP and JPSS missions.  GOES-R is expected to launch in November of 2016 and the JPSS launch is currently scheduled for early 2017.

#### COMET'S LONG HISTORY WTH GOES-R
A collaboration between NOAA and NASA, the Geostationary Operational Environmental Satellite (GOES) program celebrated its 40th anniversary in 2015.  The R Series (GOES-R) is the next generation of geostationary environmental satellites, representing the first major technological advancement in geostationary environmental observations since the mid-1990s.  GOES-R will provide measurements of the Earth’s surface and atmosphere in the Western Hemisphere for weather forecasting and severe storm tracking, and other meteorological research topics. Instruments on satellites include a high-resolution imager for images of weather phenomena, a lightening mapper that will take continuous day/night measurements of intra-cloud lightening, several instruments that measure solar phenomena, and other sensors focused on space weather.

Meanwhile, COMET began preparing professionals for GOES-R in 2008, training forecasters with simulated data. Now GOES–R is beginning important rehearsals for the launch. Aside from delivering massive amounts of data – compared to the current generation of environmental satellites - how will the new generation of GOES-R satellites be different?

*     Higher resolution, greater coverage of the electromagnetic spectrum
*     Orders of magnitude more data than the current generation of satellites
*     Real-time lightening mapper
*     Improved lead time for thunderstorm tornado and warnings
*     Improved hurricane tracking
*     Improved monitoring of solar flares and geomagnetic storms

COMET’s lessons introduce users to the significant advances these systems bring to forecasting, numerical weather prediction, and environmental monitoring. To learn more about GOES-R, please visit our MetEd lessons on Satellite Meteorology. 

The GOES-R Program also funds COMET Outreach grants that promote collaborative research between universities and weather forecast offices.

#### JPSS
The Joint Polar Satellite System collects global data as its satellites sweep over Earth’s poles, unlike the geostationary GOES-R satellites, which stay focused on a single location as they rotate with the Earth.

The JPSS program contributes vital information about Earth’s weather systems and severe storms, and it also feeds NOAA’s massive numerical weather prediction effort, since polar orbiting satellites provide critical data input to these forecast models. JPSS will allow forecasters to provide more accurate knowledge of severe weather events with longer horizon times. JPSS also adds data to long-term environmental monitoring projects, aiding our understanding of Earth’s climate, hydrology and ocean health. 

When fully deployed, JPSS satellites will cross the equator fourteen times every day, and consist of five satellites, their highly sensitive instruments, and a ground system that controls the satellites, and processes and distributes the data.

JPSS will add 30 different types of environmental data to existing records, and the information will be shared with the 88 participating countries that make up the Global Earth Observing System of System (GEOSS).

#### COMET Work with NOAA-NESDIS
COMET has prepared a broad exploration of satellite meteorology and technical training on the use of environmental satellites. Starting in 2008, most material is focused on preparing for the use of the GOES-R and JPSS satellite series.  There are lessons on the use of the new Geostationary Lightning Mapper, and Advanced Baseline Imager, space weather, river ice and flooding, and the use of water vapor in weather forecasting. Over 80 lessons on satellite meteorology are available, mostly in English and Spanish, with some in French. 

#### Additional Topics: See MetEd

*     Remote Sensing Using Satellites Learn more
*     Forecasting Fog for Aviation Learn more
*     Multispectral Satellite Applications  Learn more
*     Space-based Nighttime Observations   Learn more
*     Satellite Monitoring of Atmospheric Composition  Learn more
