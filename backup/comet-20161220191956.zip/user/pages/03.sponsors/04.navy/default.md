---
title: 'U.S. NAVY'
published: true
---

![](pagecover-navy.jpg)
## U.S. NAVY
{{ page.media['NavyEmblem.gif'].html('U.S. NAVY', 'U.S. NAVY', 'thumb-wrap navy-logo') }}
COMET has had a close relationship with the US Navy for over 25 years. Dr. Rich Jeffries, current Director of the COMET program, is a Navy veteran who has previously managed training and education for programs within the Naval Meteorological and Oceanography Command (NMOC).

The Navy relies on COMET materials for foundational training and uses over 100 COMET lessons to develop basic qualifications in topics such as meteorology, oceanography, celestial navigation, hydrography, ice prediction and other topics.

Over the years, the Navy has broadened its requirements for COMET, prompting an expansion into broader geoscience topics including hydrography with precision mapping of the ocean floor, geodesy, GPS and GIS technology.

### COMET Projects for the U.S. Navy

**Meteorology and Oceanography:** The Navy was a lead sponsor in a collaborative project that developed multiple lessons on mesoscale meteorology. In the 1990s, new observing technologies and improvements in NWP changed the practice of meteorology dramatically, and COMET trained operational forecasters in the new methods. The Navy also sponsored lessons on synoptic, satellite, arctic, tropical meteorology and oceanography.

**Geospatial:** Increasing reliance on the GPS system, dating from the mid-1990s, has required precise measurements of the time, earth observation and celestial objects. The U.S. Naval Observatory provides these measurements, and COMET lessons explain the role of the Navy in managing these resources. In addition, COMET has produced modules on geodesy, hydrography, geospatial measurements and mapping.

### Additional Topics:

* Celestial Navigation
* Oceanography / Hydrography
* Basic Observing
* Geodesy, Geospatial Measurements and Mapping
