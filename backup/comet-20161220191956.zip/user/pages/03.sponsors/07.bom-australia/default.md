---
title: 'Bureau of Meteorology - Australia'
---

![](pagecover-bom.jpeg)
### Bureau of Meteorology - Australia
{{ page.media['BOM-Logo_stacked.jpeg'].html('BOM Logo', 'BOM Logo', 'thumb-wrap bom-logo') }}
Australia’s national weather, climate and water agency helps Australian citizens deal with the country’s extreme weather and widely diverse ecosystems. The harsh realities of droughts, floods, fires, storm and tropical cyclones are common occurrences, and forecasts provided by Bureau of Meteorology are among the most widely used government services.

<br>
#### COMET History with the Bureau of Meteorology (BoM)

In 2000 the Bureau of Meteorology sent one of its employees to Boulder, Colorado to work on site at COMET in a long-term project, and develop a meteorology training module for the BoM. The intent was to give the Australian agency the tools and resources to develop its own training materials, since the country’s immense size, diverse workforce and geographical variety make distance-learning a crucial strategy for far-flung meteorology professionals. COMET provided consultation on best practices in geosciences training, and the successful project has led to a productive long-term partnership.

In 2007, COMET sent one of its most experienced instructional designers to Australia to expose the BoM staff to new distance-learning tools and processes. COMET conducted workshops on instructional development, and the 1500+ member Australian agency embarked on the development of new training tactics and materials. 

COMET has developed over a dozen training lessons (see topics below) in partnership with the Bureau of Meteorology – and continues to do so. In each case, the goal is to develop operational capacity using case-based instruction. The two organizations also work closely on projects for the World Meteorological Organization, strategizing ways to improve operational capacity among meteorologists in developing countries. 

#### ADDITIONAL TOPICS: SEE METED

*     Aviation Fog
*     Fire Weather
*     Radar Signatures
*     Severe Convective Storms
*     Climate Outlooks
