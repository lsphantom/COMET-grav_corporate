---
title: Services
---

### COMET Services
The COMET Program has a worldwide reputation and over 25 years of experience in providing innovative distance-learning education solutions for students and professionals in meteorology, hydrology, climate science, geodesy, and other geosciences.

#### COMET Audience
Originally, the COMET audience was made up of U.S. operational forecasters, but now its user group has expanded to include students, as well as environmental and geoscientists from all over the world. Furthermore, an increasing number of public and private professionals challenged with managing resources and risks to human health and infrastructure are seeking out COMET training – generally anyone who is trying to understand the impacts of weather and climate on our communities and environment. While operational weather forecasters are still an important focus of the COMET program, COMET has a growing audience of university faculty and students from over 1,900 US universities, nearly 150,000 international users, and 450,000 users total.

#### COMET Services
COMET's diverse team works closely with every client or sponsor to conduct careful needs analysis and develop the most compelling and educationally effective materials possible. COMET strives to stay ahead of the technology curve by continuously evaluating and experimenting with new software and design approaches to meet current demands.

The COMET team includes instructional designers, meteorologists, environmental scientists and geologists as well as software programmers, graphic designers, multimedia developers, videographers and translators. Together they work with each client’s subject matter experts to design lessons that present complex technical concepts in ways that can be learned efficiently, remembered, and easily incorporated into relevant work flows.

#### COMET relies upon three key training strategies to provide geoscience training and education to the global community.

1. **Distance Learning**<br>
Over 800 hours of training materials publicly available on MetEd, the COMET online learning platform, provide asynchronous, self-paced education. Since 2007, 450,000 visitors have registered to use the MetEd system and over 4,000 new users are added every month. Meanwhile last year, more than 55,000 unique users each completed an average of nearly four hours of training. The MetEd system encourages access to the multimedia elements that make up each lesson, thus providing over 40,000 individual infographics, animation or video files that can be shared with the larger community.

2. **“Virtual” Courses**<br>
Instructor-led classes at COMET link geographically diverse groups of people, and allow them to collaborate in the virtual classroom through presentations, discussions or assigned problems. COMET classrooms are equipped with the latest multimedia and communications equipment and can host up to 40 connections at the same time. Since COMET encourages participation of collaborative groups, each of these connection sites can represent a team of students. Many virtual courses developed with specific sponsors and are by invitation only, a few are open enrollment.

3. **On-site Training**<br>
COMET hosts on-site training programs at its headquarters at the University Corporation for Atmospheric Research in Boulder, Colorado. COMET has a proven history of offering these innovative, effective residence courses. We can provide can opportunities to learn using the same forecasting and modeling tools used in professional meteorological environments worldwide. Many residence courses are designed in partnership with individual sponsors and are available by invitation only. Take a look at some of our classroom offerings. Please contact us about working together to design training to meet your organization's need. 

#### COMET Capabilities
COMET has complete in-house capabilities for producing all the components for media-rich online lessons and on-site offerings including:

* Sophisticated interactive animations and graphics
* Instructional media and illustrations
* Case-based lessons
* Live and recorded webcasts
* Instructional and informational videos

#### Which Learning Strategy is Best for Your Organization?
COMET’s distance education activities provide maximum flexibility and cost effectiveness by offering a range of instructional tools and approaches. We can help you customize your learning solution to fit specific requirements based on:

* Needs assessment
* Audience characteristics
* Learning objectives
* Budget
* Time constraints (i.e., rapid turn-around for a more highly produced lesson).

<a href="#">Learn more about COMET's Instructional Design Process</a>

### COMET Instructional Design
COMET uses innovative methods to disseminate training that improves job performance in meteorology, hydrology, climate, oceanography, geodesy, space weather, and emergency management – to mention a few. Through a highly collaborative approach, COMET has created instruction that maximizes interest, learning, and retention.

#### COMET’s Instructional Design Approach

The COMET Program has always employed a systematic instructional development process to create training for geoscience professionals in a variety of topics. This process has enabled COMET to develop innovative instructional strategies that increase learner engagement, retention, and transfer of knowledge to specific work settings.

The Addie Model
#### Instructional Design in Meteorology

Our instructional designers typically use a variety of learning theories and models supported by educational psychology research:

* Cognitive apprenticeship model
* Cognitive load theory
* Scenario/problem-based learning
* Peer instruction
* Direct instruction
* Spaced and varied practice
* Blended learning
* Constructivist approaches in which students develop personalized projects
* The “testing effect.”

In addition, instructional designers have carefully studied research about the cognitive processes of weather forecasters (Pliske et al. 2004, Hahn et al. 2003, Stuart et al. 2007). Designers use this research to create learning interactions that closely match real-world tasks and mental processes involved in creating good forecasts. This research also informs training about how forecasters can continue to improve their operational skills through careful use of verification and reflection on forecast choices.

#### The ADDIE Model

The general instructional design and development process used by COMET can be characterized by the ADDIE model – Analyze, Design, Develop, Implement, Evaluate – applied in an iterative, flexible manner. The ADDIE model defines the stages of work to be accomplished for developing effective instruction.

#### COMET’s Professional Development Series (PDS) Process

COMET has developed the "Professional Development Series" process to establish training curriculum requirements based on job competencies and the associated skills and knowledge required. It consists of the following steps: 


1. COMET organizes consultations with clients, managers, and employees who are working to meet the goals of an organization.

2. The COMET instructional design team drafts competency statements to describe performance expectations along with any required supporting knowledge and skills.

3. Working collaboratively with the sponsor/client’s Subject Matter Experts (SMEs), COMET designers identify gaps in current performance and existing training offerings that could be addressed through new training implementations.

#### COMET Lesson Design
Korean Meteorological Administration training at COMETCompetencies identified through this process become the learning objectives of the respective COMET training lessons. Since competency statements are observable and measurable, they can be assessed either through direct observation or via computerized tests. After the analysis, remaining phases of development include:

* **Content Development**

The learning objectives identified in the PDS process guide the selection and organization of content, and the use and sequencing of instructional interactions for the learners. They also drive the creation of questions in the pre- and post- assessments for a training implementation. To evaluate cognitive performance on key competencies, the team writes questions that evaluate cognitive performance on the levels of application, analysis, evaluation and synthesis.

* **Graphic & Multimedia Design**

During the development phase, COMET’s instructional designers and science staff work closely with experts to create the text, images, animations, and videos in each lesson.

* **Case Studies**

COMET's instructional designers work with each sponsor's Subject Matter Experts (SME) to identify real-life scenarios that learners will work through during the training. 

* **User Testing (Optional)**

When budgets and timelines allow, COMET carries out user testing with actual learners to observe whether the lesson and assessments lead to achievement of learning objectives. In collaboration with the SMEs, feedback from testing is incorporated into the lesson.

* **Multimedia / Software Development**

After SMEs approve the content, COMET staff integrates it into multimedia software and/or course curricula.

**EVALUATION**

COMET uses parts of Kirkpatrick’s 4-Level Training Evaluation system (Kirkpatrick, 1998) to analyze how well the instructional system helps the learners to improve their performance.

**Level One:**
Evaluation focuses on questions that relate to likeability, relevance, convenience, usability, and immediate perceptions of effectiveness. COMET applies Level One evaluation surveys to all distance learning products and classroom offerings and analyzes results to improve education products.

**Level Two:**
The intent of Level Two evaluation is to determine whether learning takes place as intended. COMET measures learning via module quizzes for most of its distance learning products. Typically, COMET provides pre- and post-lesson quizzes to evaluate changes in capability after the lesson is completed.

COMET staff review quiz analytics from the MetEd website to ensure that learning outcomes are being achieved. Quizzes also provide critical data for improvements and updates to the lessons.

**Level Three:**

Often taking the form of follow-up surveys and interviews with learners and their managers, Level Three evaluations attempt to measure changes in job performance as a result of COMET training. In addition, supervisors can be asked to observe and track performance over time, performing periodic on-site exercises to test application of the training.

Though it is not always requested, COMET can package follow-up surveys, interview questions, quizzes and simulations for use on site by training officers and managers to test retention and application of the information. In an attempt to address Level Four evaluation, COMET has begun to send “booster questions” to learners in some of its residence courses. A key question asks learners to self-report whether and how they are using concepts they learned in a past COMET course.

**Level Four:**
The goal of Level Four evaluation is to determine whether COMET instruction has had a positive impact on organizational outcomes. This evaluation examines the entire learning and performance system and evaluates inputs, processes, and outputs. Reviewers determine whether organizational goals were met by the training intervention. This type of review requires questions regarding the quality of the training, the validity of original training goals and the impact of organizational factors on results.

COMET has the expertise to conduct Level Four evaluations, however the process does entail additional costs.

By engaging in this systematic process of identifying competencies and areas of performance improvement, and by continuously monitoring, analyzing, and improving its instructional offerings, COMET assists employees and organizations to meet their goals.

**DEFINITIONS**

**Cognitive apprenticeship model** - making expert thinking visible and to situate learning in real world contexts.

*     Opening scenarios that ground the material to be learned in real-world situations
*     Modeling how an expert handles a situation
*     Scaffolding the learners’ first interactions with the expert approach
*     Reflecting on the expert approach and exploring it further through problem-based learning based on real-life situations

**Cognitive load theory** is used in every COMET offering and assessment. The premise is that human beings have a limited ability to process information at any given time. Instructional designers use cognitive load theory to avoid overload; they select, organize and structure content for maximum impact and use strategies such as combining narration with animations rather than text to avoid overload, for example.

**Scenario-based learning** - COMET uses scenario-based learning to provide participants with practice using skills and strategies in a real-life context. Scenarios or case studies allow users to make mistakes when applying new information and receive expert feedback on how to improve. Educational psychology research indicates that this approach is particularly suited to science learning (Jonassen, D., Peck, K., & Wilson, B. 1999).

COMET partners with the National Weather Service (NWS) and other sponsors to develop sophisticated evaluations in the form of simulations. Case studies and simulations are a regular part of COMET residence and virtual events and case studies play a critical role in many distance-learning modules. Simulations are powerful learning tools because learners must perform the analysis and decision-making processes involved in target tasks such as forecast generation.

**Peer instruction**
After careful research into the theory and application of peer instruction in the science teaching, COMET has successfully implemented this instructional strategy in one of its Winter Weather courses. Peer instruction “engages students to apply the core concepts being presented, and then explain those concepts to their fellow students.”