---
title: 'Homepage Slider'
process:
    markdown: true
    twig: true
routable: false
visible: false
content:
    items: '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: '1'
lightslider:
    slider_type: image
    type_text_vertical_padding: 70px;
    type_text_horizontal_padding: 50px;
    type_text_brightness: -100
    mode: slide
    pager: 'true'
    controls: 'true'
    keyPress: 'true'
    pause: 3000
    speed: 1500
---

![](1-nws_supercell__shutterstock685x235.jpg)
___
![](2-GOES-R_earth_reflection_NOAA695x250.jpg)
___
![](3-oil_spill_hazards685x250.jpg)
___
![](4-hoover_dam_shutterstock_bor685x250.jpg)
___
![](5-cars_tornado_UCAR685x250.jpg)
___
![](6-fire_behaviorUCAR685x250.jpg)