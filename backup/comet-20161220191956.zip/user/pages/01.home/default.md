---
title: Home
routable: true
cache_enable: true
visible: true
lightslider:
    slider_type: text
    type_text_vertical_padding: 70px;
    type_text_horizontal_padding: 50px;
    type_text_brightness: -100
    mode: slide
    pager: 'true'
    controls: 'true'
    keyPress: 'true'
    pause: 2000
    speed: 1000
---

{#% include 'modular/lightslider.html.twig' with {'page': page.find('/home/slider')} %#}
### Welcome to the COMET<sup>&reg;</sup> Program!
<!--br-->

A program of the University Corporation for Atmospheric Research, COMET has been providing professional training and education in the geosciences for over twenty-five years. 

COMET delivers online, interactive professional development materials for meteorologists, hydrologists, climate specialists and other geoscientists. With over 800 hours of publicly available training materials on its MetEd website and 450,000 users, COMET provides a critical worldwide resource for the geoscience community. We also offer virtual, instructor-led classes as well as onsite educational opportunities for working geoscience professionals. 

Through its Outreach Program, with funding from NOAA's National Weather Service, COMET provides financial support to universities for applied research projects conducted in collaboration with local NWS forecast offices; COMET is also offering similar funding opportunities through the NWS National Water Center.

The COMET staff includes meteorologists, hydrologists, computer scientists, graphic artists, and instructional designers. We work closely with all of our sponsors and business clients to deliver effective training materials that enhance operational excellence and futher scientific knowledge.

<br>

<div class="embed-responsive embed-responsive-16by9">
  <iframe class="embed-responsive-item" src="https://www.youtube-nocookie.com/embed/OX_1MasrAhU?&vq=hd720&rel=0&showinfo=0"></iframe>
</div>

<br>